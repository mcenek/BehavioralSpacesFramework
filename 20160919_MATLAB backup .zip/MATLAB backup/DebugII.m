clear
rands = zeros (1,50000);
for i = 1:50000
    rands (i) = (ceil (rand * 816))';
end