for i = 1:20

    results(i,1) = chisquared (i,i+1,RData);
end
